Dette er mit eksamensprojekt til 1. semester, der omhandler at vi skal lave en ny hjemmeside til spillestedet Radar.

Siderne der virker på min hjemmeside er:
index.html 
omos.html
vorestilbud.html 
voresmediekanaler.html

Billederne skulle konverteres til WebP, men da hjemmesiderne kun kan konvertere 3 billeder kunne det ikke lade sig gøre for mig.